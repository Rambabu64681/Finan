package com.amrutha.financeapi.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class PortfolioResponse {

    private Long id;
    private String portfolioName;
    private BigDecimal cashBalance;
    private BigDecimal holdingsValue;
    private BigDecimal totalPortfolioValue;
    private Long clientId;
    private String clientName;
    private LocalDateTime createdAt;

    public PortfolioResponse(Long id, String portfolioName, BigDecimal cashBalance, BigDecimal holdingsValue,
                             BigDecimal totalPortfolioValue, Long clientId, String clientName, LocalDateTime createdAt) {
        this.id = id;
        this.portfolioName = portfolioName;
        this.cashBalance = cashBalance;
        this.holdingsValue = holdingsValue;
        this.totalPortfolioValue = totalPortfolioValue;
        this.clientId = clientId;
        this.clientName = clientName;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public String getPortfolioName() {
        return portfolioName;
    }

    public BigDecimal getCashBalance() {
        return cashBalance;
    }

    public BigDecimal getHoldingsValue() {
        return holdingsValue;
    }

    public BigDecimal getTotalPortfolioValue() {
        return totalPortfolioValue;
    }

    public Long getClientId() {
        return clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
