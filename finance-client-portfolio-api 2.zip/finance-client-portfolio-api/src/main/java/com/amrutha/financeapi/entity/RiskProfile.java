package com.amrutha.financeapi.entity;

public enum RiskProfile {
    CONSERVATIVE,
    MODERATE,
    AGGRESSIVE
}
