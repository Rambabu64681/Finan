package com.amrutha.financeapi.controller;

import com.amrutha.financeapi.dto.AuditLogResponse;
import com.amrutha.financeapi.service.AuditService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/audit-logs")
@CrossOrigin(origins = "*")
public class AuditController {

    private final AuditService auditService;

    public AuditController(AuditService auditService) {
        this.auditService = auditService;
    }

    @GetMapping
    public List<AuditLogResponse> getRecentAuditLogs() {
        return auditService.getRecentAuditLogs();
    }
}
