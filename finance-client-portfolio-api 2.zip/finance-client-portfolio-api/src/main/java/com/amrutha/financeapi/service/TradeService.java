package com.amrutha.financeapi.service;

import com.amrutha.financeapi.dto.TradeRequest;
import com.amrutha.financeapi.dto.TradeResponse;
import com.amrutha.financeapi.entity.Holding;
import com.amrutha.financeapi.entity.Portfolio;
import com.amrutha.financeapi.entity.Trade;
import com.amrutha.financeapi.entity.TradeType;
import com.amrutha.financeapi.exception.BadRequestException;
import com.amrutha.financeapi.repository.HoldingRepository;
import com.amrutha.financeapi.repository.TradeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class TradeService {

    private final TradeRepository tradeRepository;
    private final HoldingRepository holdingRepository;
    private final PortfolioService portfolioService;
    private final AuditService auditService;

    public TradeService(TradeRepository tradeRepository, HoldingRepository holdingRepository,
                        PortfolioService portfolioService, AuditService auditService) {
        this.tradeRepository = tradeRepository;
        this.holdingRepository = holdingRepository;
        this.portfolioService = portfolioService;
        this.auditService = auditService;
    }

    @Transactional
    public TradeResponse executeTrade(TradeRequest request) {
        Portfolio portfolio = portfolioService.findPortfolio(request.getPortfolioId());
        BigDecimal totalAmount = request.getPrice().multiply(BigDecimal.valueOf(request.getQuantity()));

        if (request.getTradeType() == TradeType.BUY) {
            executeBuy(portfolio, request, totalAmount);
        } else {
            executeSell(portfolio, request, totalAmount);
        }

        Trade trade = new Trade(
                request.getSymbol(),
                request.getTradeType(),
                request.getQuantity(),
                request.getPrice(),
                totalAmount,
                portfolio
        );

        Trade savedTrade = tradeRepository.save(trade);
        auditService.record("EXECUTE_TRADE", "TRADE", savedTrade.getId(),
                request.getTradeType() + " trade executed for " + request.getSymbol());

        return mapToResponse(savedTrade, portfolio.getId());
    }

    public List<TradeResponse> getTradesByPortfolio(Long portfolioId) {
        portfolioService.findPortfolio(portfolioId);

        return tradeRepository.findByPortfolioIdOrderByExecutedAtDesc(portfolioId)
                .stream()
                .map(trade -> mapToResponse(trade, portfolioId))
                .toList();
    }

    private void executeBuy(Portfolio portfolio, TradeRequest request, BigDecimal totalAmount) {
        if (portfolio.getCashBalance().compareTo(totalAmount) < 0) {
            throw new BadRequestException("Insufficient cash balance for BUY trade");
        }

        Holding holding = holdingRepository.findByPortfolioIdAndSymbol(portfolio.getId(), request.getSymbol())
                .orElse(new Holding(request.getSymbol(), 0, BigDecimal.ZERO, portfolio));

        int existingQuantity = holding.getQuantity();
        int newQuantity = existingQuantity + request.getQuantity();

        BigDecimal existingValue = holding.getAverageCost().multiply(BigDecimal.valueOf(existingQuantity));
        BigDecimal newAverageCost = existingValue.add(totalAmount)
                .divide(BigDecimal.valueOf(newQuantity), 2, RoundingMode.HALF_UP);

        holding.setQuantity(newQuantity);
        holding.setAverageCost(newAverageCost);
        holdingRepository.save(holding);

        portfolio.setCashBalance(portfolio.getCashBalance().subtract(totalAmount));
        portfolioService.savePortfolio(portfolio);
    }

    private void executeSell(Portfolio portfolio, TradeRequest request, BigDecimal totalAmount) {
        Holding holding = holdingRepository.findByPortfolioIdAndSymbol(portfolio.getId(), request.getSymbol())
                .orElseThrow(() -> new BadRequestException("No holdings available for symbol: " + request.getSymbol()));

        if (holding.getQuantity() < request.getQuantity()) {
            throw new BadRequestException("Insufficient holdings for SELL trade");
        }

        holding.setQuantity(holding.getQuantity() - request.getQuantity());

        if (holding.getQuantity() == 0) {
            holdingRepository.delete(holding);
        } else {
            holdingRepository.save(holding);
        }

        portfolio.setCashBalance(portfolio.getCashBalance().add(totalAmount));
        portfolioService.savePortfolio(portfolio);
    }

    private TradeResponse mapToResponse(Trade trade, Long portfolioId) {
        return new TradeResponse(
                trade.getId(),
                portfolioId,
                trade.getSymbol(),
                trade.getTradeType(),
                trade.getQuantity(),
                trade.getPrice(),
                trade.getTotalAmount(),
                trade.getExecutedAt()
        );
    }
}
