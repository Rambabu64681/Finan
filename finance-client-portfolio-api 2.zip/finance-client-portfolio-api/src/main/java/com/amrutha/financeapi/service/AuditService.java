package com.amrutha.financeapi.service;

import com.amrutha.financeapi.dto.AuditLogResponse;
import com.amrutha.financeapi.entity.AuditLog;
import com.amrutha.financeapi.repository.AuditLogRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    public AuditService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    public void record(String action, String entityType, Long entityId, String description) {
        auditLogRepository.save(new AuditLog(action, entityType, entityId, description));
    }

    public List<AuditLogResponse> getRecentAuditLogs() {
        return auditLogRepository.findTop50ByOrderByCreatedAtDesc()
                .stream()
                .map(log -> new AuditLogResponse(
                        log.getId(),
                        log.getAction(),
                        log.getEntityType(),
                        log.getEntityId(),
                        log.getDescription(),
                        log.getCreatedAt()
                ))
                .toList();
    }
}
