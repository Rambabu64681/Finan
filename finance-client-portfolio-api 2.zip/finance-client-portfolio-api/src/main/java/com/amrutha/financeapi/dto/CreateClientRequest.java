package com.amrutha.financeapi.dto;

import com.amrutha.financeapi.entity.RiskProfile;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class CreateClientRequest {

    @NotBlank(message = "Full name is required")
    private String fullName;

    @Email(message = "Valid email is required")
    @NotBlank(message = "Email is required")
    private String email;

    @NotNull(message = "Risk profile is required")
    private RiskProfile riskProfile;

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public RiskProfile getRiskProfile() {
        return riskProfile;
    }
}
