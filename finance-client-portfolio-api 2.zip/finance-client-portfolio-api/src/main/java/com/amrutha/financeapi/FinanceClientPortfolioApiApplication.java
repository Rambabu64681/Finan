package com.amrutha.financeapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinanceClientPortfolioApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinanceClientPortfolioApiApplication.class, args);
    }
}
