package com.amrutha.financeapi.repository;

import com.amrutha.financeapi.entity.Holding;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface HoldingRepository extends JpaRepository<Holding, Long> {
    Optional<Holding> findByPortfolioIdAndSymbol(Long portfolioId, String symbol);
    List<Holding> findByPortfolioId(Long portfolioId);
}
