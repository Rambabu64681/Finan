package com.amrutha.financeapi.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "clients")
public class Client {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fullName;

    @Column(unique = true, nullable = false)
    private String email;

    @Enumerated(EnumType.STRING)
    private RiskProfile riskProfile;

    private LocalDateTime createdAt;

    @OneToMany(mappedBy = "client", cascade = CascadeType.ALL)
    private List<Portfolio> portfolios = new ArrayList<>();

    public Client() {
    }

    public Client(String fullName, String email, RiskProfile riskProfile) {
        this.fullName = fullName;
        this.email = email;
        this.riskProfile = riskProfile;
        this.createdAt = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public RiskProfile getRiskProfile() {
        return riskProfile;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
