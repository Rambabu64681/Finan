package com.amrutha.financeapi.controller;

import com.amrutha.financeapi.dto.TradeRequest;
import com.amrutha.financeapi.dto.TradeResponse;
import com.amrutha.financeapi.service.TradeService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trades")
@CrossOrigin(origins = "*")
public class TradeController {

    private final TradeService tradeService;

    public TradeController(TradeService tradeService) {
        this.tradeService = tradeService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TradeResponse executeTrade(@Valid @RequestBody TradeRequest request) {
        return tradeService.executeTrade(request);
    }

    @GetMapping("/portfolio/{portfolioId}")
    public List<TradeResponse> getTradesByPortfolio(@PathVariable Long portfolioId) {
        return tradeService.getTradesByPortfolio(portfolioId);
    }
}
