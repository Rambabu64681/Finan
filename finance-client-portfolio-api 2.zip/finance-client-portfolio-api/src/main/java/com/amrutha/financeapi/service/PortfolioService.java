package com.amrutha.financeapi.service;

import com.amrutha.financeapi.dto.CreatePortfolioRequest;
import com.amrutha.financeapi.dto.HoldingResponse;
import com.amrutha.financeapi.dto.PortfolioResponse;
import com.amrutha.financeapi.entity.Client;
import com.amrutha.financeapi.entity.Holding;
import com.amrutha.financeapi.entity.Portfolio;
import com.amrutha.financeapi.exception.ResourceNotFoundException;
import com.amrutha.financeapi.repository.HoldingRepository;
import com.amrutha.financeapi.repository.PortfolioRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class PortfolioService {

    private final PortfolioRepository portfolioRepository;
    private final HoldingRepository holdingRepository;
    private final ClientService clientService;
    private final AuditService auditService;

    public PortfolioService(PortfolioRepository portfolioRepository, HoldingRepository holdingRepository,
                            ClientService clientService, AuditService auditService) {
        this.portfolioRepository = portfolioRepository;
        this.holdingRepository = holdingRepository;
        this.clientService = clientService;
        this.auditService = auditService;
    }

    public PortfolioResponse createPortfolio(CreatePortfolioRequest request) {
        Client client = clientService.findClient(request.getClientId());

        Portfolio portfolio = new Portfolio(
                request.getPortfolioName(),
                request.getInitialCashBalance(),
                client
        );

        Portfolio savedPortfolio = portfolioRepository.save(portfolio);
        auditService.record("CREATE_PORTFOLIO", "PORTFOLIO", savedPortfolio.getId(), "Created client investment portfolio");

        return mapToResponse(savedPortfolio);
    }

    public List<PortfolioResponse> getAllPortfolios() {
        return portfolioRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public List<PortfolioResponse> getPortfoliosByClient(Long clientId) {
        clientService.findClient(clientId);
        return portfolioRepository.findByClientId(clientId)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public PortfolioResponse getPortfolioById(Long id) {
        return mapToResponse(findPortfolio(id));
    }

    public List<HoldingResponse> getHoldings(Long portfolioId) {
        findPortfolio(portfolioId);

        return holdingRepository.findByPortfolioId(portfolioId)
                .stream()
                .map(this::mapToHoldingResponse)
                .toList();
    }

    public Portfolio findPortfolio(Long id) {
        return portfolioRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Portfolio not found with id: " + id));
    }

    public Portfolio savePortfolio(Portfolio portfolio) {
        return portfolioRepository.save(portfolio);
    }

    private PortfolioResponse mapToResponse(Portfolio portfolio) {
        BigDecimal holdingsValue = calculateHoldingsValue(portfolio.getId());
        BigDecimal totalPortfolioValue = portfolio.getCashBalance().add(holdingsValue);

        return new PortfolioResponse(
                portfolio.getId(),
                portfolio.getPortfolioName(),
                portfolio.getCashBalance(),
                holdingsValue,
                totalPortfolioValue,
                portfolio.getClient().getId(),
                portfolio.getClient().getFullName(),
                portfolio.getCreatedAt()
        );
    }

    private HoldingResponse mapToHoldingResponse(Holding holding) {
        BigDecimal marketValue = holding.getAverageCost().multiply(BigDecimal.valueOf(holding.getQuantity()));

        return new HoldingResponse(
                holding.getId(),
                holding.getSymbol(),
                holding.getQuantity(),
                holding.getAverageCost(),
                marketValue,
                holding.getUpdatedAt()
        );
    }

    private BigDecimal calculateHoldingsValue(Long portfolioId) {
        return holdingRepository.findByPortfolioId(portfolioId)
                .stream()
                .map(holding -> holding.getAverageCost().multiply(BigDecimal.valueOf(holding.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
