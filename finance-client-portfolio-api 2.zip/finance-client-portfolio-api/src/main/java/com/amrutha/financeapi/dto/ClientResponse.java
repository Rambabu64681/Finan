package com.amrutha.financeapi.dto;

import com.amrutha.financeapi.entity.RiskProfile;
import java.time.LocalDateTime;

public class ClientResponse {

    private Long id;
    private String fullName;
    private String email;
    private RiskProfile riskProfile;
    private LocalDateTime createdAt;

    public ClientResponse(Long id, String fullName, String email, RiskProfile riskProfile, LocalDateTime createdAt) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.riskProfile = riskProfile;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public RiskProfile getRiskProfile() {
        return riskProfile;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
