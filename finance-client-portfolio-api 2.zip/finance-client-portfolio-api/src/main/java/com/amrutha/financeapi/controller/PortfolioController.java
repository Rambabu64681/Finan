package com.amrutha.financeapi.controller;

import com.amrutha.financeapi.dto.CreatePortfolioRequest;
import com.amrutha.financeapi.dto.HoldingResponse;
import com.amrutha.financeapi.dto.PortfolioResponse;
import com.amrutha.financeapi.service.PortfolioService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/portfolios")
@CrossOrigin(origins = "*")
public class PortfolioController {

    private final PortfolioService portfolioService;

    public PortfolioController(PortfolioService portfolioService) {
        this.portfolioService = portfolioService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public PortfolioResponse createPortfolio(@Valid @RequestBody CreatePortfolioRequest request) {
        return portfolioService.createPortfolio(request);
    }

    @GetMapping
    public List<PortfolioResponse> getAllPortfolios() {
        return portfolioService.getAllPortfolios();
    }

    @GetMapping("/{id}")
    public PortfolioResponse getPortfolioById(@PathVariable Long id) {
        return portfolioService.getPortfolioById(id);
    }

    @GetMapping("/client/{clientId}")
    public List<PortfolioResponse> getPortfoliosByClient(@PathVariable Long clientId) {
        return portfolioService.getPortfoliosByClient(clientId);
    }

    @GetMapping("/{portfolioId}/holdings")
    public List<HoldingResponse> getHoldings(@PathVariable Long portfolioId) {
        return portfolioService.getHoldings(portfolioId);
    }
}
