package com.amrutha.financeapi.repository;

import com.amrutha.financeapi.entity.Portfolio;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PortfolioRepository extends JpaRepository<Portfolio, Long> {
    List<Portfolio> findByClientId(Long clientId);
}
