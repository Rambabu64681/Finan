package com.amrutha.financeapi.dto;

import com.amrutha.financeapi.entity.TradeType;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TradeResponse {

    private Long id;
    private Long portfolioId;
    private String symbol;
    private TradeType tradeType;
    private Integer quantity;
    private BigDecimal price;
    private BigDecimal totalAmount;
    private LocalDateTime executedAt;

    public TradeResponse(Long id, Long portfolioId, String symbol, TradeType tradeType, Integer quantity,
                         BigDecimal price, BigDecimal totalAmount, LocalDateTime executedAt) {
        this.id = id;
        this.portfolioId = portfolioId;
        this.symbol = symbol;
        this.tradeType = tradeType;
        this.quantity = quantity;
        this.price = price;
        this.totalAmount = totalAmount;
        this.executedAt = executedAt;
    }

    public Long getId() {
        return id;
    }

    public Long getPortfolioId() {
        return portfolioId;
    }

    public String getSymbol() {
        return symbol;
    }

    public TradeType getTradeType() {
        return tradeType;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public LocalDateTime getExecutedAt() {
        return executedAt;
    }
}
