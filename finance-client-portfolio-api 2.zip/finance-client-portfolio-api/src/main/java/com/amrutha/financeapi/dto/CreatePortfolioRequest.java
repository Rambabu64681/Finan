package com.amrutha.financeapi.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public class CreatePortfolioRequest {

    @NotNull(message = "Client id is required")
    private Long clientId;

    @NotBlank(message = "Portfolio name is required")
    private String portfolioName;

    @NotNull(message = "Initial cash balance is required")
    @DecimalMin(value = "0.0", inclusive = true, message = "Initial cash balance cannot be negative")
    private BigDecimal initialCashBalance;

    public Long getClientId() {
        return clientId;
    }

    public String getPortfolioName() {
        return portfolioName;
    }

    public BigDecimal getInitialCashBalance() {
        return initialCashBalance;
    }
}
