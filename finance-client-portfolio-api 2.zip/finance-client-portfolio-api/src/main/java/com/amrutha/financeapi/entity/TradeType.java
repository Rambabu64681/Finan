package com.amrutha.financeapi.entity;

public enum TradeType {
    BUY,
    SELL
}
