package com.amrutha.financeapi.service;

import com.amrutha.financeapi.dto.ClientResponse;
import com.amrutha.financeapi.dto.CreateClientRequest;
import com.amrutha.financeapi.entity.Client;
import com.amrutha.financeapi.exception.BadRequestException;
import com.amrutha.financeapi.exception.ResourceNotFoundException;
import com.amrutha.financeapi.repository.ClientRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClientService {

    private final ClientRepository clientRepository;
    private final AuditService auditService;

    public ClientService(ClientRepository clientRepository, AuditService auditService) {
        this.clientRepository = clientRepository;
        this.auditService = auditService;
    }

    public ClientResponse createClient(CreateClientRequest request) {
        clientRepository.findByEmail(request.getEmail()).ifPresent(client -> {
            throw new BadRequestException("Client already exists with email: " + request.getEmail());
        });

        Client client = new Client(request.getFullName(), request.getEmail(), request.getRiskProfile());
        Client savedClient = clientRepository.save(client);
        auditService.record("CREATE_CLIENT", "CLIENT", savedClient.getId(), "Created finance client profile");

        return mapToResponse(savedClient);
    }

    public List<ClientResponse> getAllClients() {
        return clientRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public ClientResponse getClientById(Long id) {
        Client client = findClient(id);
        return mapToResponse(client);
    }

    public Client findClient(Long id) {
        return clientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Client not found with id: " + id));
    }

    private ClientResponse mapToResponse(Client client) {
        return new ClientResponse(
                client.getId(),
                client.getFullName(),
                client.getEmail(),
                client.getRiskProfile(),
                client.getCreatedAt()
        );
    }
}
