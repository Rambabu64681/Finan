package com.amrutha.financeapi.repository;

import com.amrutha.financeapi.entity.Trade;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TradeRepository extends JpaRepository<Trade, Long> {
    List<Trade> findByPortfolioIdOrderByExecutedAtDesc(Long portfolioId);
}
