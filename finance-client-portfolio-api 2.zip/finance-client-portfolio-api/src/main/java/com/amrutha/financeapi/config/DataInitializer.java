package com.amrutha.financeapi.config;

import com.amrutha.financeapi.dto.CreateClientRequest;
import com.amrutha.financeapi.dto.CreatePortfolioRequest;
import com.amrutha.financeapi.dto.TradeRequest;
import com.amrutha.financeapi.entity.RiskProfile;
import com.amrutha.financeapi.entity.TradeType;
import com.amrutha.financeapi.service.ClientService;
import com.amrutha.financeapi.service.PortfolioService;
import com.amrutha.financeapi.service.TradeService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DataInitializer implements CommandLineRunner {

    private final ClientService clientService;
    private final PortfolioService portfolioService;
    private final TradeService tradeService;

    public DataInitializer(ClientService clientService, PortfolioService portfolioService, TradeService tradeService) {
        this.clientService = clientService;
        this.portfolioService = portfolioService;
        this.tradeService = tradeService;
    }

    @Override
    public void run(String... args) {
        clientService.createClient(new SeedClientRequest(
                "Demo Client",
                "demo.client@example.com",
                RiskProfile.MODERATE
        ));

        portfolioService.createPortfolio(new SeedPortfolioRequest(
                1L,
                "Demo Growth Portfolio",
                new BigDecimal("50000")
        ));

        tradeService.executeTrade(new SeedTradeRequest(
                1L,
                "AAPL",
                TradeType.BUY,
                20,
                new BigDecimal("180.00")
        ));

        tradeService.executeTrade(new SeedTradeRequest(
                1L,
                "MSFT",
                TradeType.BUY,
                10,
                new BigDecimal("410.00")
        ));
    }

    private static class SeedClientRequest extends CreateClientRequest {
        private final String fullName;
        private final String email;
        private final RiskProfile riskProfile;

        SeedClientRequest(String fullName, String email, RiskProfile riskProfile) {
            this.fullName = fullName;
            this.email = email;
            this.riskProfile = riskProfile;
        }

        @Override public String getFullName() { return fullName; }
        @Override public String getEmail() { return email; }
        @Override public RiskProfile getRiskProfile() { return riskProfile; }
    }

    private static class SeedPortfolioRequest extends CreatePortfolioRequest {
        private final Long clientId;
        private final String portfolioName;
        private final BigDecimal initialCashBalance;

        SeedPortfolioRequest(Long clientId, String portfolioName, BigDecimal initialCashBalance) {
            this.clientId = clientId;
            this.portfolioName = portfolioName;
            this.initialCashBalance = initialCashBalance;
        }

        @Override public Long getClientId() { return clientId; }
        @Override public String getPortfolioName() { return portfolioName; }
        @Override public BigDecimal getInitialCashBalance() { return initialCashBalance; }
    }

    private static class SeedTradeRequest extends TradeRequest {
        private final Long portfolioId;
        private final String symbol;
        private final TradeType tradeType;
        private final Integer quantity;
        private final BigDecimal price;

        SeedTradeRequest(Long portfolioId, String symbol, TradeType tradeType, Integer quantity, BigDecimal price) {
            this.portfolioId = portfolioId;
            this.symbol = symbol;
            this.tradeType = tradeType;
            this.quantity = quantity;
            this.price = price;
        }

        @Override public Long getPortfolioId() { return portfolioId; }
        @Override public String getSymbol() { return symbol; }
        @Override public TradeType getTradeType() { return tradeType; }
        @Override public Integer getQuantity() { return quantity; }
        @Override public BigDecimal getPrice() { return price; }
    }
}
