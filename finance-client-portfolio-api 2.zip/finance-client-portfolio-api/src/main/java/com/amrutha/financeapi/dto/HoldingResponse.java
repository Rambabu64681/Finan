package com.amrutha.financeapi.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class HoldingResponse {

    private Long id;
    private String symbol;
    private Integer quantity;
    private BigDecimal averageCost;
    private BigDecimal marketValue;
    private LocalDateTime updatedAt;

    public HoldingResponse(Long id, String symbol, Integer quantity, BigDecimal averageCost,
                           BigDecimal marketValue, LocalDateTime updatedAt) {
        this.id = id;
        this.symbol = symbol;
        this.quantity = quantity;
        this.averageCost = averageCost;
        this.marketValue = marketValue;
        this.updatedAt = updatedAt;
    }

    public Long getId() {
        return id;
    }

    public String getSymbol() {
        return symbol;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public BigDecimal getAverageCost() {
        return averageCost;
    }

    public BigDecimal getMarketValue() {
        return marketValue;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
}
