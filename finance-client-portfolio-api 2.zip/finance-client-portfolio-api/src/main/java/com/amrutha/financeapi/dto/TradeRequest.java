package com.amrutha.financeapi.dto;

import com.amrutha.financeapi.entity.TradeType;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public class TradeRequest {

    @NotNull(message = "Portfolio id is required")
    private Long portfolioId;

    @NotBlank(message = "Symbol is required")
    private String symbol;

    @NotNull(message = "Trade type is required")
    private TradeType tradeType;

    @NotNull(message = "Quantity is required")
    @Min(value = 1, message = "Quantity must be greater than zero")
    private Integer quantity;

    @NotNull(message = "Price is required")
    @DecimalMin(value = "0.01", inclusive = true, message = "Price must be greater than zero")
    private BigDecimal price;

    public Long getPortfolioId() {
        return portfolioId;
    }

    public String getSymbol() {
        return symbol == null ? null : symbol.toUpperCase();
    }

    public TradeType getTradeType() {
        return tradeType;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }
}
