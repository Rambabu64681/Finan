package com.amrutha.financeapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanceClientPortfolioApiApplicationTests {

    @Test
    void contextLoads() {
    }
}
