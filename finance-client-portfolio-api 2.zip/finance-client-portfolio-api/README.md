# Finance Client Portfolio API

A GitHub-ready Java Spring Boot project built around a finance/client investment portfolio use case.

This project simulates a finance client platform where advisors can create clients, open portfolios, manage cash balances, execute buy/sell trades, track holdings, calculate portfolio exposure, and maintain audit records.

## Why this project is useful for your resume

This project demonstrates real enterprise development skills:

- Java and Spring Boot backend development
- REST API design
- Finance-domain business logic
- Microservices-style layered architecture
- DTO validation
- Exception handling
- JPA/Hibernate persistence
- Transaction management
- Audit logging
- Swagger API documentation
- Docker support
- GitHub Actions CI/CD pipeline
- H2 in-memory database for easy local testing

## Tech Stack

- Java 17
- Spring Boot 3
- Spring Web
- Spring Data JPA
- Hibernate
- H2 Database
- Maven
- Swagger/OpenAPI
- Docker
- GitHub Actions
- Actuator

## Main Features

### Client Management
- Create finance clients
- Retrieve all clients
- Retrieve client by ID

### Portfolio Management
- Create investment portfolios for clients
- Maintain portfolio cash balance
- View client portfolio summary
- Track total portfolio value

### Trade Management
- Execute BUY trades
- Execute SELL trades
- Validate cash balance before BUY
- Validate holdings before SELL
- Update holdings automatically after trade execution
- Store complete trade history

### Audit Logging
- Store audit records for important business actions
- Track entity type, entity ID, action, and timestamp

## Run Locally

```bash
mvn clean install
mvn spring-boot:run
```

Application:

```text
http://localhost:8080
```

Swagger UI:

```text
http://localhost:8080/swagger-ui.html
```

H2 Console:

```text
http://localhost:8080/h2-console
```

JDBC URL:

```text
jdbc:h2:mem:financedb
```

## Sample API Flow

### 1. Create Client

```http
POST /api/clients
```

```json
{
  "fullName": "Amrutha Priya",
  "email": "amrutha@example.com",
  "riskProfile": "MODERATE"
}
```

### 2. Create Portfolio

```http
POST /api/portfolios
```

```json
{
  "clientId": 1,
  "portfolioName": "Growth Portfolio",
  "initialCashBalance": 25000
}
```

### 3. Execute BUY Trade

```http
POST /api/trades
```

```json
{
  "portfolioId": 1,
  "symbol": "AAPL",
  "tradeType": "BUY",
  "quantity": 10,
  "price": 180.50
}
```

### 4. Execute SELL Trade

```http
POST /api/trades
```

```json
{
  "portfolioId": 1,
  "symbol": "AAPL",
  "tradeType": "SELL",
  "quantity": 2,
  "price": 185.00
}
```

## GitHub Upload Commands

```bash
git init
git add .
git commit -m "Initial commit - Finance Client Portfolio API"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/finance-client-portfolio-api.git
git push -u origin main
```

## Resume Project Description

Finance Client Portfolio API is a Java Spring Boot backend application designed to manage client investment portfolios, execute buy/sell trades, track holdings, calculate portfolio value, and maintain audit logs. Built REST APIs using Spring Boot, JPA, H2, validation, exception handling, Docker, Swagger, and GitHub Actions CI/CD.

## Interview Explanation

In this project, I designed a finance-domain backend API where clients can be created, portfolios can be opened, and trades can be executed. The business logic validates available cash for buy trades and available holdings for sell trades. I used a layered architecture with controllers, services, repositories, DTOs, entities, and global exception handling. I also added audit logging to track major actions, Swagger for API documentation, Docker for containerization, and GitHub Actions for CI/CD.
